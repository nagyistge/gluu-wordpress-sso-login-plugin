jQuery(document).ready(function () {	
	//show mcrypt extension installation reason
    jQuery("#help_openid_mcrypt_title").click(function () {
        jQuery("#help_openid_mcrypt").toggle();
    });
	
	jQuery("#openid_login_shortcode_title").click(function () {
    	jQuery("#openid_login_shortcode").slideToggle(400);
    });
	jQuery("#openid_sharing_shortcode_title").click(function () {
    	jQuery("#openid_sharing_shortcode").slideToggle(400);
    });
	jQuery("#openid_shortcode_inphp_title").click(function () {
    	jQuery("#openid_shortcode_inphp").slideToggle(400);
    });
	jQuery("#openid_question1").click(function () {
    	jQuery("#openid_question1_desc").slideToggle(400);
    });
	jQuery("#openid_question2").click(function () {
    	jQuery("#openid_question2_desc").slideToggle(400);
    });
	jQuery("#openid_question3").click(function () {
    	jQuery("#openid_question3_desc").slideToggle(400);
    });
	jQuery("#openid_question4").click(function () {
    	jQuery("#openid_question4_desc").slideToggle(400);
    });
	jQuery("#openid_question5").click(function () {
    	jQuery("#openid_question5_desc").slideToggle(400);
    });
	jQuery("#openid_question6").click(function () {
    	jQuery("#openid_question6_desc").slideToggle(400);
    });
	jQuery("#openid_question7").click(function () {
    	jQuery("#openid_question7_desc").slideToggle(400);
    });
	jQuery("#openid_question8").click(function () {
    	jQuery("#openid_question8_desc").slideToggle(400);
    });
	jQuery("#openid_question9").click(function () {
    	jQuery("#openid_question9_desc").slideToggle(400);
    });
	jQuery("#openid_question10").click(function () {
    	jQuery("#openid_question10_desc").slideToggle(400);
    });
	jQuery("#openid_question11").click(function () {
    	jQuery("#openid_question11_desc").slideToggle(400);
    });
	jQuery("#openid_question12").click(function () {
    	jQuery("#openid_question12_desc").slideToggle(400);
    });
	jQuery("#openid_question_curl").click(function () {
    	jQuery("#openid_question_curl_desc").slideToggle(400);
    });
	jQuery("#openid_question_otp").click(function () {
    	jQuery("#openid_question_otp_desc").slideToggle(400);
    });
	jQuery("#openid_question_login").click(function () {
    	jQuery("#openid_question_login_desc").slideToggle(400);
    });
	jQuery("#openid_question_sharing").click(function () {
    	jQuery("#openid_question_sharing_desc").slideToggle(400);
    });
	jQuery("#openid_question_logout").click(function () {
    	jQuery("#openid_question_logout_desc").slideToggle(400);
    });
});